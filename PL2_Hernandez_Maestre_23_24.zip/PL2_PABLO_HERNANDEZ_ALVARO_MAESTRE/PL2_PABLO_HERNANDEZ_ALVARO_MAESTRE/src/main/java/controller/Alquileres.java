
package controller;

import java.time.*;
import java.util.*;
import model.Inmueble;

public class Alquileres {
    private LocalDateTime hoy;
    private LocalDateTime finAlquiler;
    private Inmueble alquilado;
        
   
}
